1. Type 'make' to compile the GTThreads library 
2. Type 'make matrix' to compile the matrix program
3. ./bin/matrix -s 1 -lb to run the matrix program
4. python3 data_process.py to run data processor
5. python3 make_graph.py to make graph
